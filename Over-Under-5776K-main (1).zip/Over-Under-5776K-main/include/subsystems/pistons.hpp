extern pros::ADIDigitalOut pistonPTO1;
extern pros::ADIDigitalOut pistonPTO2;

void pistons();