#include "main.h"

using namespace okapi;

void encoderAvg();
void movePID(float target, float maxV);
void turnPID(float target, bool CW, int ms);

void IEInnit()
void imuInnit();